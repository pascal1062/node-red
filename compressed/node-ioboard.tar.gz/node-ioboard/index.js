"use strict"

var addon = require('./build/Release/addon');

module.exports.readIP = function(address, callback)
{
	return addon.readIP(address, callback)
}

module.exports.readIPSync = function(address)
{
	return addon.readIPSync(address)
}

module.exports.writeOP = function(address_no, output_no, output_value, callback)
{
	return addon.writeOP(address_no, output_no, output_value, callback);
}

module.exports.writeOPSync = function(address_no, output_no, output_value)
{
	return addon.writeOPSync(address_no, output_no, output_value);
}