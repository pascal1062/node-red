/*********************************************************************
 * PiCubes - Native libarry for Pi-Cubes Modules
 *
 * Copyright (c) 2015 Cube-Controls Inc.
 *
 * MIT License
 ********************************************************************/

#include <nan.h>
#include "readip.h"    // NOLINT(build/include)
#include "writeop.h"   // NOLINT(build/include)

using v8::FunctionTemplate;
using v8::Handle;
using v8::Object;
using v8::String;
using Nan::GetFunction;
using Nan::New;
using Nan::Set;

// Expose synchronous and asynchronous access to our
// Estimate() function
NAN_MODULE_INIT(InitAll) {
  Set(target, New<String>("readIP").ToLocalChecked(),
    GetFunction(New<FunctionTemplate>(readIP)).ToLocalChecked());

  Set(target, New<String>("readIPSync").ToLocalChecked(),
    GetFunction(New<FunctionTemplate>(readIPSync)).ToLocalChecked());

  Set(target, New<String>("writeOP").ToLocalChecked(),
    GetFunction(New<FunctionTemplate>(writeOP)).ToLocalChecked());

  Set(target, New<String>("writeOPSync").ToLocalChecked(),
    GetFunction(New<FunctionTemplate>(writeOPSync)).ToLocalChecked());
}


NODE_MODULE(addon, InitAll)
