/*********************************************************************
 * PiCubes - Native libarry for Pi-Cubes Modules
 *
 * Copyright (c) 2015 Cube-Controls Inc.
 *
 * MIT License
 ********************************************************************/

#ifndef READIP_H
#define READIP_H

#include <nan.h>

NAN_METHOD(readIP);
NAN_METHOD(readIPSync);

#endif  // READIP_H
