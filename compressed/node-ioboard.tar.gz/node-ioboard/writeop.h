/*********************************************************************
 * PiCubes - Native libarry for Pi-Cubes Modules
 *
 * Copyright (c) 2015 Cube-Controls Inc.
 *
 * MIT License
 ********************************************************************/

#ifndef WRITEOP_H
#define WRITEOP_H

#include <nan.h>

NAN_METHOD(writeOP);
NAN_METHOD(writeOPSync);

#endif  // WRITEOP_H
