/*********************************************************************
 * PiCubes - Native libarry for Pi-Cubes Modules
 *
 * Copyright (c) 2015 Cube-Controls Inc.
 *
 * MIT License
 ********************************************************************/

#include <nan.h>
#include "writeop.h"  // NOLINT(build/include)
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <unistd.h>

using v8::Function;
using v8::Local;
using v8::Number;
using v8::Value;
using Nan::AsyncQueueWorker;
using Nan::AsyncWorker;
using Nan::Callback;
using Nan::HandleScope;
using Nan::New;
using Nan::Null;
using Nan::To;

class writeOPWorker : public AsyncWorker {
 public:
  writeOPWorker(Callback *callback, int address, int output, int value)
    : AsyncWorker(callback), address(address), output(output), value(value) {}
  ~writeOPWorker() {}

  // Executed inside the worker-thread.
  // It is not safe to access V8, or V8 data structures
  // here, so everything we need for input and output
  // should go on `this`.
  void Execute () {
    unsigned char buf[10];
    int fd;

	if ((output < 1) || (output > 8))
	{
		SetErrorMessage("Output number out of range");
		return;
	}

    // Open port for reading and writing
    if ((fd = open("/dev/i2c-1", O_RDWR)) < 0)
    {
		SetErrorMessage("Failed to open i2c-1 port.");
		return;
    }

	// Set the port options and set the address of the device we wish to speak to
	if (ioctl(fd, I2C_SLAVE, address) < 0)
	{
		SetErrorMessage("Unable to get bus access to talk to Pi-Cubes I/O module.");
		return;
	}

	// calculate output vs address
	if (output == 1) {
		buf[0] = 85;
	} else if (output == 2){
		buf[0] = 86;
	} else if (output == 3){
		buf[0] = 87;
	} else if (output == 4){
		buf[0] = 88;
	} else if (output == 5){
		buf[0] = 89;
	} else if (output == 6){
		buf[0] = 90;
	} else if (output == 7){
		buf[0] = 91;
	} else if (output == 8){
		buf[0] = 92;
	}
	buf[1] = (unsigned char)(value);

	// Send address and value to I/O module
	if ((write(fd, buf, 2)) != 2)
	{
		SetErrorMessage("Error writing to Pi-Cubes I/O module.");
		return;
	}

	// Close Port
	close(fd);
  }

  // Executed when the async work is complete
  // this function will be run inside the main event loop
  // so it is safe to use V8 again
  void HandleOKCallback () {
    HandleScope scope;

    Local<Value> argv[] = {
        Null()
    };

    callback->Call(1, argv);
  }

 private:
  int address;
  int output;
  int value;
};

// Asynchronous WriteDO
NAN_METHOD(writeOP) {
  int address = To<int>(info[0]).FromJust();
  int output = To<int>(info[1]).FromJust();
  int value = To<int>(info[2]).FromJust();
  Callback *callback = new Callback(info[3].As<Function>());

  if (info.Length() != 4)
  {
    return Nan::ThrowError("Incorect number of parameters passed to writeOPSync function !");
  }

  AsyncQueueWorker(new writeOPWorker(callback, address, output, value));
}

// Ssynchronous WriteDO
NAN_METHOD(writeOPSync) {
	// expect a number as the first argument
	int address = To<int>(info[0]).FromJust();
	int output = To<int>(info[1]).FromJust();
	int value = To<int>(info[2]).FromJust();

	unsigned char buf[10];
	int fd;

	if ((output < 1) || (output > 8))
	{
		return Nan::ThrowRangeError("Output number out of range");
	}

    // Open port for reading and writing
    if ((fd = open("/dev/i2c-1", O_RDWR)) < 0)
    {
		return;
    }

	 // Set the port options and set the address of the device we wish to speak to
	if (ioctl(fd, I2C_SLAVE, address) < 0)
	{
		return;
	}

	// calculate output vs address
	if (output == 1) {
		buf[0] = 85;
	} else if (output == 2){
		buf[0] = 86;
	} else if (output == 3){
		buf[0] = 87;
	} else if (output == 4){
		buf[0] = 88;
	} else if (output == 5){
		buf[0] = 89;
	} else if (output == 6){
		buf[0] = 90;
	} else if (output == 7){
		buf[0] = 91;
	} else if (output == 8){
		buf[0] = 92;
	}
	buf[1] = (unsigned char)(value);

	// Send address and value to I/O module
	if ((write(fd, buf, 2)) != 2)
	{
		return;
	}

	// Close Port
	close(fd);

	info.GetReturnValue().Set(0);
}
