module.exports = function(RED) {
	
    function ScaleRangeNode(config) {
        RED.nodes.createNode(this,config);
        this.volts = config.volts;
        this.values= config.values;
        var node = this;
        
        this.on('input', function(msg) {
        	var _advalue = msg.payload;
        	var _voltvalue = JSON.parse(node.volts);  
        	var _calcvalue = JSON.parse(node.values);  
        	var _tempCalc = 0.0;
        	var _diffvolt = 0.0;
        	var _diffcalc = 0.0;
        	var _newvalue = 0.0;
        	var _lastvalue = 0.0;
        	var volt = _advalue * (5.0 / 1023.0);

        	for (x = 0; x < _voltvalue.length; x++) {
        		if ((volt >= _voltvalue[x+1]) & (volt <= _voltvalue[x])) {
        	        _diffvolt = _voltvalue[x] - _voltvalue[x+1];
        	        _diffcalc = _calcvalue[x+1] - _calcvalue[x];
        	        _tempCalc = _calcvalue[x+1] - ((volt - _voltvalue[x+1]) * (_diffcalc/_diffvolt));
        		} else {
        	        if (volt <= _voltvalue[_voltvalue.length - 1]) {
        	            _tempCalc = _calcvalue[_voltvalue.length - 1]; 
        	        } else if (volt >= _voltvalue[0]) {
        	            _tempCalc = _calcvalue[0];
        		    }		
        	    }
        	}
        	
        	var msg = {payload:Number(_tempCalc)};
            node.send(msg);
        });
    }
    
    RED.nodes.registerType("scalerange",ScaleRangeNode);
}
